import turtle

# --- Setup ---
t = turtle.Turtle()
t.pensize(5)        # Choose pen thickness
t.pencolor("blue")  # Choose color
t.speed(3)

# --- Draw the letter S ---
t.penup()
t.goto(-100, 0)
t.pendown()

# Draw an S using a series of lines
t.forward(60)
t.left(90)
t.forward(60)
t.left(90)
t.forward(60)
t.right(90)
t.forward(60)
t.right(90)
t.forward(60)

# --- Move to draw the letter M ---
t.penup()
t.goto(100, 0)
t.pendown()

# Change color if you like
t.pencolor("green")

# Draw an M
t.left(90)
t.forward(120)
t.right(135)
t.forward(60)
t.left(90)
t.forward(60)
t.right(135)
t.forward(120)

# --- Finish ---
t.hideturtle()
turtle.done()
