import turtle

# Set up the turtle
t = turtle.Turtle()
t.pensize(3)

# Draw a square using a for loop
for i in range(4):
    t.forward(100)
    t.right(90)

# Move a bit before drawing the triangle (still using loop logic)
t.penup()
t.forward(150)
t.pendown()

# Draw a triangle using a while loop
sides = 0
while sides < 3:
    t.forward(100)
    t.left(120)
    sides += 1

# Keep the window open
turtle.done()
