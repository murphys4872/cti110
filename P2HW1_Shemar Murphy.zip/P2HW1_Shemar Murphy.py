# Shemar Murphy
# October 12, 2025
# P2HW1_ MurphyShemar
# This program calculates and displays trip expenses, showing each category neatly formatted with two decimal places and dollar signs.

# Ask user for trip details
destination = input("Enter your travel destination: ")
budget = float(input("Enter your budget: "))
gas = float(input("How much do you think you will spend on gas? "))
accommodation = float(input("Approximately, how much will you need for accommodation/hotel? "))
food = float(input("How much do you think you will spend on food? "))

# Calculate total expenses and remaining balance
total_expenses = gas + accommodation + food
remaining_balance = budget - total_expenses

# Display formatted output
print("\n------------Travel Expenses------------")
print(f"{'Location:':20}{destination}")
print(f"{'Initial Budget:':20}${budget:,.2f}")
print(f"{'Fuel:':20}${gas:,.2f}")
print(f"{'Accommodation:':20}${accommodation:,.2f}")
print(f"{'Food:':20}${food:,.2f}")
print("---------------------------------------")
print(f"{'Remaining Balance:':20}${remaining_balance:,.2f}")
