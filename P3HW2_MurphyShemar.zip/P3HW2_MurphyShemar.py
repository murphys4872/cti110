# *******************************************************
# Author: Shemar Murphy
# Date: 11/2/2025
# Assignment Name: P3HW2 - Salary Calculation with Overtime
# Description: This program calculates the salary of an employee,
#              including regular and overtime pay based on the number of hours worked.
# *******************************************************

# Pseudocode (algorithm) for the program:
#
# 1. Ask user for employee's name
# 2. Ask user for the number of hours the employee worked
# 3. Ask user for the employee's hourly pay rate
# 4. If the employee worked overtime (more than 40 hours):
#    - Calculate the overtime pay (1.5 times the hourly rate)
# 5. Calculate the pay for regular hours (up to 40 hours)
# 6. Calculate the total (gross) pay
# 7. Display the employee's details: name, hours worked, overtime hours, pay rate, regular pay, overtime pay, and gross pay

# Step 1: Ask the user for employee details
employee_name = input("Enter employee's name: ")
hours_worked = float(input("Enter number of hours worked: "))
pay_rate = float(input("Enter employee's pay rate: "))

# Step 2: Initialize overtime variables
overtime_hours = 0
overtime_pay = 0

# Step 3: Calculate regular pay and overtime pay
if hours_worked > 40:
    # Calculate overtime
    overtime_hours = hours_worked - 40
    overtime_pay = overtime_hours * (pay_rate * 1.5)
    regular_pay = 40 * pay_rate  # Only 40 hours are paid at the normal rate
else:
    # No overtime worked
    regular_pay = hours_worked * pay_rate

# Step 4: Calculate gross pay
gross_pay = regular_pay + overtime_pay

# Step 5: Display the results in a table-like format
print("\n----------------------------- Employee Salary Details -----------------------------")
print(f"{'Employee name:':<20} {employee_name}")
print(f"{'Hours Worked':<15} {'Pay Rate':<10} {'OverTime':<10} {'OverTime Pay':<15} {'RegHour Pay':<15} {'Gross Pay':<15}")
print("-------------------------------------------------------------------------------")
print(f"{hours_worked:<15.2f} {pay_rate:<10.2f} {overtime_hours:<10.2f} {overtime_pay:<15.2f} {regular_pay:<15.2f} {gross_pay:<15.2f}")
