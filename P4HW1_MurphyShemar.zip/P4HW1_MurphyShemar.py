# Shemar Murphy
# November 9, 2025
# P4HW1
# This program asks the user how many scores they would like to enter,
# validates each score to ensure it’s between 0 and 100,
# and then calculates the lowest score, highest score, average,
# and displays all the results neatly.

# Ask the user how many scores they want to enter
num_scores = int(input("How many scores would you like to enter? "))

# Initialize an empty list to store the scores
scores = []

# Loop to collect and validate scores
for i in range(1, num_scores + 1):
    print(f"\nEnter score #{i}:")
    score = float(input())

    # Validate that the score is between 0 and 100
    while score < 0 or score > 100:
        print("INVALID Score entered!!!!")
        print("Score should be between 0 and 100.")
        score = float(input(f"Enter score #{i} again: "))

    # Add valid score to the list
    scores.append(score)

# Calculate statistics
lowest_score = min(scores)
highest_score = max(scores)
average_score = sum(scores) / len(scores)

# Display results
print("\n----------Results----------")
print(f"Scores entered: {scores}")
print(f"Lowest score: {lowest_score}")
print(f"Highest score: {highest_score}")
print(f"Average score: {average_score:.2f}")

# Optional: display a letter grade based on the average
if average_score >= 90:
    grade = "A"
elif average_score >= 80:
    grade = "B"
elif average_score >= 70:
    grade = "C"
elif average_score >= 60:
    grade = "D"
else:
    grade = "F"

print(f"Letter grade: {grade}")
print("-------------------------")