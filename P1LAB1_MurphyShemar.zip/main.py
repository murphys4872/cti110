user_name = input()

Pat=input
print('Hello Pat and welcome to CS Online!')