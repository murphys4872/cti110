# Shemar Murphy
# October 12, 2025
# P2LAB1
# This project calculates and displays the diameter, circumference, 
# and area of a circle based on a given radius using standard formulas.

radius = 8.75

diameter = 2 * radius
circumference = 2 * 3.1416 * radius
area = 3.1416 * radius ** 2

print("The diameter of the circle is", diameter)
print("The circumference of the circle is", round(circumference, 2))
print("The area of the circle is", round(area, 3))
