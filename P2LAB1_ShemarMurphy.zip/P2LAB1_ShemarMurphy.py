# Shemar Murphy
# October 12, 2025
# P2LAB1
# This program calculates and displays the diameter, circumference, and area of a circle based on the user's input radius.

import math

# Ask user for radius
radius = float(input("What is the radius of the circle? "))

# Perform calculations
diameter = 2 * radius
circumference = 2 * math.pi * radius
area = math.pi * radius**2

# Display results
print(f"\nThe diameter of the circle is {diameter}")
print(f"\nThe circumference of the circle is {circumference:.2f}")
print(f"\nThe area of the circle is {area:.3f}")
