# Shemar Murphy
# November 9, 2025
# P4HW2
# This program calculates the gross pay for multiple employees.
# It repeatedly asks for an employee's name, hours worked, and pay rate.
# The program computes regular pay, overtime pay, and gross pay for each employee.
# When the user enters "Done" as the employee name, the program displays
# the total overtime pay, total regular pay, total gross pay, and
# the total number of employees entered.

# Initialize totals
total_overtime_pay = 0
total_regular_pay = 0
total_gross_pay = 0
employee_count = 0

# Prompt for the first employee name
employee_name = input("Enter employee's name or 'Done' to terminate: ")

# Loop until the user types 'Done'
while employee_name.lower() != "done":
    # Get hours worked and pay rate
    hours_worked = float(input(f"Enter number of hours worked by {employee_name}: "))
    pay_rate = float(input(f"Enter {employee_name}'s pay rate: "))

    # Calculate overtime and regular hours
    if hours_worked > 40:
        overtime_hours = hours_worked - 40
        regular_hours = 40
    else:
        overtime_hours = 0
        regular_hours = hours_worked

    # Calculate pay amounts
    overtime_pay = overtime_hours * pay_rate * 1.5
    regular_pay = regular_hours * pay_rate
    gross_pay = regular_pay + overtime_pay

    # Update totals
    total_overtime_pay += overtime_pay
    total_regular_pay += regular_pay
    total_gross_pay += gross_pay
    employee_count += 1

    # Display results for this employee
    print("\n----------------------------------------")
    print(f"Employee name: {employee_name}")
    print(f"Hours Worked   Pay Rate   Overtime Pay   Regular Pay   Gross Pay")
    print("---------------------------------------------------------------")
    print(f"{hours_worked:<14.2f}{pay_rate:<11.2f}{overtime_pay:<15.2f}{regular_pay:<14.2f}{gross_pay:.2f}")
    print("---------------------------------------------------------------\n")

    # Ask for the next employee
    employee_name = input("Enter employee's name or 'Done' to terminate: ")

# Display totals after all employees are entered
print("\n=========== Payroll Summary ===========")
print(f"Total number of employees entered: {employee_count}")
print(f"Total amount paid for overtime: ${total_overtime_pay:.2f}")
print(f"Total amount paid for regular pay: ${total_regular_pay:.2f}")
print(f"Total gross pay for all employees: ${total_gross_pay:.2f}")
print("========================================")
