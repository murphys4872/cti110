def display_multiplication_table(num):
    # Display multiplication table using a for loop
    print(f"\nMultiplication Table for {num}:")
    for i in range(1, 13):  # 1 to 12
        print(f"{num} x {i} = {num * i}")

def main():
    while True:
        # Get user input for an integer
        user_input = input("Enter an integer: ")

        # Check if the input is an integer and process it
        try:
            num = int(user_input)
            if num >= 0:
                # Display the multiplication table if the number is >= 0
                display_multiplication_table(num)

                # Ask if the user wants to run the program again
                run_again = input("\nWould you like to run the program again? (yes/no): ").lower()

                # Handle user choice to continue or quit
                if run_again == 'no':
                    print("Goodbye!")
                    break  # Exit the loop and end the program
                elif run_again != 'yes':
                    print("Invalid response. The program will now exit.")
                    break  # Exit on invalid response

            else:
                print("Cannot accept negative values. Please enter a positive integer or zero.")

        except ValueError:
            print("Invalid input. Please enter a valid integer.")

# Run the program
main()
